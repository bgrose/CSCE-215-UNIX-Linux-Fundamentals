#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright:  Duncan Buell. All rights reserved.
 * Date: 28 December 2014
 *
 * Revised: Bradley Grose.
 * Date: 19 February 2020.
**/

int main(int argc, char *argv[])
{
  cout << "Hello, world." << endl;
  cout << "My name is Bradley Grose." << endl;

  return 0;
}

